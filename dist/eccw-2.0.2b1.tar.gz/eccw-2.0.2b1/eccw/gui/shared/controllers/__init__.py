#!/usr/bin/env python3
# -*-coding:utf-8 -*

"""
Base graphic elements used to build the differents parts of the GUI.
Controllers that inherits from form implementation generated from reading ui files and from normalised wrappers that allows automatic and recursive setting/getting.
"""
