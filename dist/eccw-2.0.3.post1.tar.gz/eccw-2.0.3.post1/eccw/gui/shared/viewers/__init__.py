#!/usr/bin/env python3
# -*-coding:utf-8 -*

"""
Base graphic elements used to build the differents parts of the GUI.
Form implementation generated from reading ui files
"""
