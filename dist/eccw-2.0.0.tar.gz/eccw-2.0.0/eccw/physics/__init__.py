#!/usr/bin/env python3
# -*-coding:utf-8 -*

"""
Core module of eccw library.
Contains elements to compute and display what matters : physics !
"""
