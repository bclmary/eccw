#!/usr/bin/env python3
# -*-coding:utf-8 -*

"""
Part of the GUI that compute various parameters of the Critical Coulomb Wedge.
"""
