#!/usr/bin/env python3
# -*-coding:utf-8 -*

"""
Part of the GUI that plot critical Coulomb Wedge enveloppes.
"""
